#ifndef _CMACRO_H
#define _CMACRO_H
#include <stdlib.h>
#define  YES  1
#define  NO 0
#endif
