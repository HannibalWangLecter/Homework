//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PhoneBook.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PHONEBOOK_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_NAME                        1000
#define IDC_HOMEPHONE                   1001
#define IDC_TELEPHONE                   1002
#define IDC_OFFICEPHONE                 1003
#define IDC_GROUP                       1004
#define IDC_EMAIL                       1005
#define IDC_RECORD                      1006
#define ID_NAME                         1007
#define ID_TELEPHONE                    1008
#define ID_HPHONE                       1009
#define ID_OPHONE                       1010
#define ID_EMAIL                        1011
#define ID_GROUP                        1012
#define ID_RECOARD                      1013
#define IDC_UP                          1014
#define IDC_DOWN                        1015
#define IDC_ADD                         1016
#define IDCALTER                        1017
#define IDC_ALTER                       1017
#define IDC_UPDATE                      1018
#define IDC_DELETE                      1019
#define IDC_SEARCH1                     1020
#define IDC_NAMESEARCH                  1021
#define IDC_TELEPHONESEARCH             1022
#define IDC_HPHONESEARCH                1023
#define IDC_OPHONESEARCH                1024
#define IDC_LIST1                       1025
#define IDC_LIST2                       1026
#define IDC_SEARCH2                     1027
#define IDC_GROUPSEARCH                 1028
#define IDC_END                         1029
#define IDGROUP                         1030
#define IDC_OUTPUT                      1031
#define IDC_INPUT                       1032
#define IDC_BUTTON1                     1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
