#ifndef PHONECARD_
#define PHONECARD_

struct Phone
{
	char name[20];
	char tel_phone[11];
	char off_phone[12];
	char home_phone[12];
	char email[25];
	char group[10];
	char speech[100];
};

#endif