#include"BitTree.h"

	int main ()
	{
		tree *t;
		t=inittree();
		bianli(t);
		return 0;
	}
